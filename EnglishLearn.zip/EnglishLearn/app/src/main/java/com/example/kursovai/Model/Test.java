package com.example.kursovai.Model;

public class Test {
    public String testName;

    public Test(String testName) {
        this.testName = testName;
    }

    public String getTestName() {
        return testName;
    }

    public Test() {}

    public void setTestName(String testName) {
        this.testName = testName;
    }
}
